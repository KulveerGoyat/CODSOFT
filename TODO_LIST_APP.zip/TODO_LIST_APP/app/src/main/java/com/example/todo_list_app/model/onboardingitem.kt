package com.example.todo_list_app_codesoft.model

data class OnBoardingItem(
    val title : String,
    val description : String,
    val image : Int
)
